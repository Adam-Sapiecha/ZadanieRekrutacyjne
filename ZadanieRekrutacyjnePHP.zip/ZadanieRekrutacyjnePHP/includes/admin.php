<?php

function np_register_dashboard_page() {
    add_submenu_page(
        'tools.php',
        'Top Posty',
        'Top Posty',
        'manage_options',
        'np-top-posts',
        'np_dashboard_render'
    );
}
add_action('admin_menu', 'np_register_dashboard_page');

function np_dashboard_render() {
    $args = [
        'post_type' => 'post',
        'posts_per_page' => 5,
        'meta_key' => 'np_post_views',
        'orderby' => 'meta_value_num',
        'order' => 'DESC'
    ];
    $query = new WP_Query($args);

    echo '<div class="wrap"><h1>Najczęściej oglądane posty</h1>';
    echo '<table class="widefat"><thead><tr><th>Tytuł</th><th>Wyświetlenia</th><th>Edytuj</th></tr></thead><tbody>';

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            echo '<tr>';
            echo '<td>' . get_the_title() . '</td>';
            echo '<td>' . get_post_meta(get_the_ID(), 'np_post_views', true) . '</td>';
            echo '<td><a href="' . get_edit_post_link() . '">Edytuj</a></td>';
            echo '</tr>';
        }
        wp_reset_postdata();
    } else {
        echo '<tr><td colspan="3">Brak danych</td></tr>';
    }

    echo '</tbody></table></div>';
}
