<?php
/*
Plugin Name: Zadanie rekrutacyjne PHP
Description: Wtyczka do zliczania wyświetlen postów
Author: Adam Sapiecha
*/

if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/admin.php';

function np_track_post_views() {
    if (!is_single()) return;

    global $post;
    if (!$post) return;

    if (!session_id()) session_start();

    $post_id = $post->ID;

    if (!isset($_SESSION['np_post_views'])) {
        $_SESSION['np_post_views'] = [];
    }

    if (!in_array($post_id, $_SESSION['np_post_views'])) {
        $views = (int) get_post_meta($post_id, 'np_post_views', true);
        update_post_meta($post_id, 'np_post_views', $views + 1);
        $_SESSION['np_post_views'][] = $post_id;
    }
}
add_action('wp', 'np_track_post_views');

function np_show_post_views($content) {
    if (is_single() && in_the_loop() && is_main_query()) {
        global $post;
        $views = (int) get_post_meta($post->ID, 'np_post_views', true);
        $content .= '<p><strong>Liczba wyświetleń: ' . esc_html($views) . '</strong></p>';
    }
    return $content;
}
add_filter('the_content', 'np_show_post_views');
